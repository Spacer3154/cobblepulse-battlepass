package fr.cobblepulse.battlepass.integration;

import eu.pb4.placeholders.api.PlaceholderResult;
import eu.pb4.placeholders.api.Placeholders;
import fr.cobblepulse.battlepass.BattlePass;
import fr.cobblepulse.battlepass.config.Cfg;
import fr.cobblepulse.battlepass.core.TextUtil;
import fr.cobblepulse.battlepass.core.TimeFmt;
import fr.cobblepulse.battlepass.data.PlayerData;
import fr.cobblepulse.battlepass.season.Season;
import fr.cobblepulse.battlepass.storage.PlayerStore;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

/** Placeholders %cobblepulse_battlepass:...% (Text Placeholder API). Ne jamais referencer si le mod est absent. */
final class PlaceholderHook {
    private PlaceholderHook() {}

    private static void reg(String id, Function<class_3222, class_2561> fn) {
        Placeholders.register(class_2960.method_60655(BattlePass.MOD_ID, id), (ctx, arg) -> {
            class_3222 p = ctx.player();
            if (p == null) return PlaceholderResult.invalid("No player!");
            return PlaceholderResult.value(fn.apply(p));
        });
    }

    private static void global(String id, java.util.function.Supplier<class_2561> fn) {
        Placeholders.register(class_2960.method_60655(BattlePass.MOD_ID, id), (ctx, arg) -> PlaceholderResult.value(fn.get()));
    }

    /** Etoile du chat : ★ premium, ☆ passe gratuit (pendant une saison en cours), rien sinon. */
    static class_2561 star(class_3222 p) {
        String st = Season.status();
        if (Cfg.pass.debut <= 0 || "terminee".equals(st)) return class_2561.method_43473();
        PlayerData d = PlayerStore.get(p);
        String fmt = Season.isPremium(d, p) ? Cfg.pass.etoiles.premium : Cfg.pass.etoiles.gratuit;
        return fmt == null || fmt.isEmpty() ? class_2561.method_43473() : TextUtil.legacy(fmt);
    }

    static void register() {
        reg("etoile", PlaceholderHook::star);
        reg("palier", p -> class_2561.method_43470(String.valueOf(Season.tier(PlayerStore.get(p)))));
        reg("points", p -> class_2561.method_43470(String.valueOf(PlayerStore.get(p).points)));
        reg("premium", p -> class_2561.method_43470(Season.isPremium(PlayerStore.get(p), p) ? "oui" : "non"));
        reg("serie", p -> class_2561.method_43470(String.valueOf(PlayerStore.get(p).serie)));
        reg("a_reclamer", p -> class_2561.method_43470(String.valueOf(Season.claimable(PlayerStore.get(p), p))));
        reg("points_prochain_palier", p -> {
            PlayerData d = PlayerStore.get(p);
            int t = Season.tier(d);
            if (t >= Cfg.pass.paliers) return class_2561.method_43470("0");
            return class_2561.method_43470(String.valueOf(Cfg.pass.totalFor(t + 1) - d.points));
        });
        global("saison", () -> class_2561.method_43470(Cfg.pass.nom));
        global("paliers", () -> class_2561.method_43470(String.valueOf(Cfg.pass.paliers)));
        global("temps_restant", () -> class_2561.method_43470(TimeFmt.duration(Math.max(0, Season.end() - TimeFmt.now()))));
        global("statut", () -> class_2561.method_43470(fr.cobblepulse.battlepass.core.Msg.raw("status." + Season.status())));
    }
}
