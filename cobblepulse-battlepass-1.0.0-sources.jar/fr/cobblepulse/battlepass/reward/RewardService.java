package fr.cobblepulse.battlepass.reward;

import com.cobblemon.mod.common.Cobblemon;
import com.cobblemon.mod.common.api.storage.party.PlayerPartyStore;
import com.cobblemon.mod.common.item.PokemonItem;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import fr.cobblepulse.battlepass.BattlePass;
import fr.cobblepulse.battlepass.config.Cfg;
import fr.cobblepulse.battlepass.core.ItemBuilder;
import fr.cobblepulse.battlepass.core.Json;
import fr.cobblepulse.battlepass.core.TextUtil;
import fr.cobblepulse.battlepass.data.MonSpec;
import fr.cobblepulse.battlepass.data.PlayerData;
import fr.cobblepulse.battlepass.data.Reward;
import fr.cobblepulse.battlepass.integration.BattletowerBridge;
import fr.cobblepulse.battlepass.integration.JobsBridge;
import fr.cobblepulse.battlepass.season.Season;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Distribution et affichage des recompenses (objets, Pokemon, commandes, BP Battletower, coins Jobs+, points). */
public final class RewardService {
    private static final Map<String, class_1799> ICON_CACHE = new HashMap<>();
    private static int cacheRevision = -1;

    private RewardService() {}

    public static class_7225.class_7874 regs() {
        MinecraftServer s = BattlePass.server();
        return s == null ? null : s.method_30611();
    }

    // ------------------------------------------------------------------ Objets (JSON de Minecraft)

    /** Objet decrit en JSON ({"id", "count", "components"}) ; la quantite peut depasser 99 (distribuee en plusieurs piles). */
    public static class_1799 decodeItem(JsonElement json) {
        class_7225.class_7874 regs = regs();
        if (json == null || regs == null) return class_1799.field_8037;
        try {
            int count = 1;
            JsonElement parse = json;
            if (json.isJsonObject()) {
                JsonObject o = json.getAsJsonObject().deepCopy();
                if (o.has("count")) count = Math.max(1, o.get("count").getAsInt());
                o.addProperty("count", 1);
                parse = o;
            } else if (json.isJsonPrimitive()) {
                JsonObject o = new JsonObject();
                o.addProperty("id", json.getAsString());
                o.addProperty("count", 1);
                parse = o;
            }
            class_1799 s = class_1799.field_24671.parse(class_6903.method_46632(JsonOps.INSTANCE, regs), parse).result().orElse(class_1799.field_8037);
            if (!s.method_7960()) s.method_7939(count);
            return s;
        } catch (Exception e) {
            return class_1799.field_8037;
        }
    }

    public static JsonElement encodeItem(class_1799 stack) {
        class_7225.class_7874 regs = regs();
        if (stack == null || stack.method_7960() || regs == null) return null;
        int count = stack.method_7947();
        class_1799 one = stack.method_46651(1);
        JsonElement e = class_1799.field_24671.encodeStart(class_6903.method_46632(JsonOps.INSTANCE, regs), one).result().orElse(null);
        if (e != null && e.isJsonObject()) e.getAsJsonObject().addProperty("count", count);
        return e;
    }

    /** Donne l'objet (piles decoupees) ; ce qui ne rentre pas dans l'inventaire tombe aux pieds du joueur. */
    public static void giveItem(class_3222 p, class_1799 stack) {
        int left = stack.method_7947();
        int max = Math.max(1, stack.method_7914());
        while (left > 0) {
            int n = Math.min(max, left);
            class_1799 part = stack.method_46651(n);
            if (!p.method_31548().method_7394(part) || !part.method_7960()) {
                if (!part.method_7960()) p.method_7328(part, false);
            }
            left -= n;
        }
        p.field_7512.method_7623();
    }

    // ------------------------------------------------------------------ Pokemon

    public static void givePokemon(class_3222 p, Pokemon pk) {
        PlayerPartyStore party = Cobblemon.INSTANCE.getStorage().getParty(p);
        if (!party.add(pk)) Cobblemon.INSTANCE.getStorage().getPC(p).add(pk);
    }

    // ------------------------------------------------------------------ Distribution

    /** Recompense prete a etre donnee (verifiee a l'avance pour ne rien donner a moitie). */
    public interface Prepared {
        void give();
    }

    /** Verifie la recompense ; renvoie null (et une erreur) si elle ne peut pas etre donnee maintenant. */
    public static Prepared prepare(class_3222 p, PlayerData d, Reward r, List<String> errors) {
        r.normalize();
        String who = p.method_7334().getName();
        switch (r.type()) {
            case "objet" -> {
                class_1799 s = decodeItem(r.objet);
                if (s.method_7960()) {
                    errors.add("objet invalide (" + (r.objet == null ? "vide" : r.objet.toString()) + ")");
                    return null;
                }
                return () -> giveItem(p, s);
            }
            case "pokemon" -> {
                List<String> errs = new ArrayList<>();
                Pokemon pk = PokemonFactory.create(r.pokemon, errs);
                if (pk == null) {
                    errors.addAll(errs);
                    return null;
                }
                if (!errs.isEmpty()) BattlePass.LOG.warn("[BattlePass] Recompense Pokemon {} : {}", r.pokemon.species, String.join(" | ", errs));
                return () -> givePokemon(p, pk);
            }
            case "commande" -> {
                if (r.commandes.isEmpty()) {
                    errors.add("aucune commande");
                    return null;
                }
                List<String> cmds = new ArrayList<>(r.commandes);
                return () -> runCommands(p.method_5682(), cmds, who, p.method_5667().toString());
            }
            case "bp_battletower" -> {
                if (!BattletowerBridge.present()) {
                    errors.add("CobblePulse Battletower n'est pas installé");
                    return null;
                }
                long n = Math.round(r.montant);
                return () -> BattletowerBridge.give(p.method_5667(), who, n);
            }
            case "coins_jobs" -> {
                if (!JobsBridge.usable(p)) {
                    errors.add("Jobs+ n'est pas installé");
                    return null;
                }
                double n = r.montant;
                return () -> JobsBridge.add(p, n);
            }
            case "points" -> {
                long n = Math.round(r.montant);
                return () -> Season.addPoints(d, p, n, "recompense", false);
            }
            default -> {
                errors.add("type inconnu " + r.type);
                return null;
            }
        }
    }

    /** Donne une liste de recompenses en tout ou rien. */
    public static boolean giveAll(class_3222 p, PlayerData d, List<Reward> rewards, List<String> errors) {
        List<Prepared> ready = new ArrayList<>();
        for (Reward r : rewards) {
            Prepared pr = prepare(p, d, r, errors);
            if (pr == null) return false;
            ready.add(pr);
        }
        for (Prepared pr : ready) {
            try {
                pr.give();
            } catch (Throwable t) {
                BattlePass.LOG.error("[BattlePass] Erreur en donnant une recompense a {}", p.method_7334().getName(), t);
            }
        }
        return true;
    }

    public static void runCommands(MinecraftServer server, List<String> commands, String player, String uuid) {
        if (server == null) return;
        for (String c : commands) {
            String cmd = c.trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            cmd = cmd.replace("%player%", player).replace("%joueur%", player).replace("%uuid%", uuid);
            try {
                server.method_3734().method_44252(server.method_3739(), cmd);
            } catch (Throwable t) {
                BattlePass.LOG.warn("[BattlePass] Commande de recompense en echec '{}' : {}", cmd, t.toString());
            }
        }
    }

    // ------------------------------------------------------------------ Affichage

    private static String defaultIcon(String type) {
        return switch (type) {
            case "pokemon" -> "cobblemon:poke_ball";
            case "bp_battletower" -> "minecraft:emerald";
            case "coins_jobs" -> "minecraft:gold_ingot";
            case "points" -> "minecraft:experience_bottle";
            default -> "minecraft:paper";
        };
    }

    /** Icone (objet affiche) de la recompense : l'objet lui-meme, le modele du Pokemon, ou l'icone choisie. */
    public static class_1799 icon(Reward r) {
        if (cacheRevision != Cfg.revision) {
            ICON_CACHE.clear();
            cacheRevision = Cfg.revision;
        }
        r.normalize();
        switch (r.type()) {
            case "objet" -> {
                class_1799 s = decodeItem(r.objet);
                return s.method_7960() ? new class_1799(class_1802.field_8077) : s;
            }
            case "pokemon" -> {
                String key = Json.COMPACT.toJson(r.pokemon);
                class_1799 cached = ICON_CACHE.get(key);
                if (cached != null) return cached.method_7972();
                class_1799 out;
                try {
                    Pokemon pk = PokemonFactory.create(Json.copy(r.pokemon, MonSpec.class), new ArrayList<>());
                    out = pk == null ? new class_1799(class_1802.field_8077) : PokemonItem.from(pk);
                } catch (Throwable t) {
                    out = new class_1799(class_1802.field_8077);
                }
                ICON_CACHE.put(key, out.method_7972());
                return out;
            }
            default -> {
                String id = r.icone.isBlank() ? defaultIcon(r.type()) : r.icone;
                return new class_1799(ItemBuilder.item(id.contains(":") ? id : "minecraft:" + id, class_1802.field_8407));
            }
        }
    }

    /** Nom affiche de la recompense. */
    public static class_5250 name(Reward r) {
        if (!r.nom.isBlank()) return TextUtil.legacy(r.nom);
        switch (r.type()) {
            case "objet" -> {
                class_1799 s = decodeItem(r.objet);
                if (s.method_7960()) return class_2561.method_43470("Objet invalide").method_27692(class_124.field_1061);
                class_5250 c = class_2561.method_43473().method_10852(s.method_7964());
                return s.method_7947() > 1 ? c.method_10852(class_2561.method_43470(" x" + s.method_7947())) : c;
            }
            case "pokemon" -> {
                MonSpec m = r.pokemon;
                class_5250 c = class_2561.method_43473();
                var sp = SpeciesLookup.resolve(m.species);
                c.method_10852(sp == null ? class_2561.method_43470(m.species) : sp.getTranslatedName());
                c.method_10852(class_2561.method_43470(" Nv. " + m.level));
                if (m.shiny) c.method_10852(class_2561.method_43470(" ★").method_27692(class_124.field_1065));
                return c;
            }
            case "bp_battletower" -> {
                return class_2561.method_43470(fmt(r.montant) + " BP (Tour de Combat)").method_27692(class_124.field_1060);
            }
            case "coins_jobs" -> {
                return class_2561.method_43470(fmt(r.montant) + " coins Jobs+").method_27692(class_124.field_1065);
            }
            case "points" -> {
                return class_2561.method_43470(fmt(r.montant) + " points de passe").method_27692(class_124.field_1075);
            }
            default -> {
                return class_2561.method_43470("Récompense spéciale");
            }
        }
    }

    public static String fmt(double v) {
        return v == Math.rint(v) ? String.valueOf((long) v) : String.format(Locale.ROOT, "%.2f", v);
    }

    /** Details (infobulle) d'une recompense. */
    public static List<class_5250> lore(Reward r) {
        List<class_5250> out = new ArrayList<>();
        switch (r.type()) {
            case "pokemon" -> {
                MonSpec m = r.pokemon;
                if (m.shiny) out.add(class_2561.method_43470("Chromatique").method_27692(class_124.field_1065));
                if (!m.form.isBlank()) out.add(class_2561.method_43470("Forme : " + m.form).method_27692(class_124.field_1080));
                if (!m.nickname.isBlank()) out.add(class_2561.method_43470("Surnom : " + m.nickname).method_27692(class_124.field_1080));
                if (!m.nature.isBlank()) out.add(class_2561.method_43470("Nature : " + Names.nature(m.nature)).method_27692(class_124.field_1080));
                if (!m.ability.isBlank()) out.add(class_2561.method_43470("Talent : " + m.ability).method_27692(class_124.field_1080));
                String g = PokemonFactory.gender(m.gender);
                if (!g.isEmpty()) out.add(class_2561.method_43470("Genre : " + Names.gender(g)).method_27692(class_124.field_1080));
                StringBuilder iv = new StringBuilder();
                boolean anyIv = false;
                for (String s : MonSpec.STATS) {
                    int v = m.iv(s);
                    if (v >= 0) anyIv = true;
                    iv.append(iv.length() == 0 ? "" : " / ").append(v < 0 ? "?" : String.valueOf(v));
                }
                if (anyIv) out.add(class_2561.method_43470("IV : " + iv).method_27692(class_124.field_1075));
                int evTotal = 0;
                StringBuilder ev = new StringBuilder();
                for (String s : MonSpec.STATS) {
                    evTotal += m.ev(s);
                    ev.append(ev.length() == 0 ? "" : " / ").append(m.ev(s));
                }
                if (evTotal > 0) out.add(class_2561.method_43470("EV : " + ev).method_27692(class_124.field_1076));
                if (!m.moves.isEmpty()) out.add(class_2561.method_43470("Capacités : " + String.join(", ", m.moves)).method_27692(class_124.field_1080));
                if (!m.heldItem.isBlank()) out.add(class_2561.method_43470("Objet tenu : " + m.heldItem).method_27692(class_124.field_1080));
                if (!m.ball.isBlank()) out.add(class_2561.method_43470("Ball : " + m.ball).method_27692(class_124.field_1080));
                if (!m.teraType.isBlank()) out.add(class_2561.method_43470("Type Téra : " + m.teraType).method_27692(class_124.field_1080));
            }
            case "commande" -> out.add(class_2561.method_43470("Récompense spéciale").method_27692(class_124.field_1080));
            default -> {
            }
        }
        return out;
    }
}
