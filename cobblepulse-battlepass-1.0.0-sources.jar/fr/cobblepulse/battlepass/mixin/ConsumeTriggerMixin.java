package fr.cobblepulse.battlepass.mixin;

import fr.cobblepulse.battlepass.quest.QuestHooks;
import net.minecraft.class_1799;
import net.minecraft.class_2010;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Aliments consommes pour les quetes "manger". */
@Mixin(class_2010.class)
public abstract class ConsumeTriggerMixin {
    @Inject(method = "trigger", at = @At("HEAD"))
    private void cpbp$consumed(class_3222 player, class_1799 item, CallbackInfo ci) {
        QuestHooks.onConsumed(player, item);
    }
}
