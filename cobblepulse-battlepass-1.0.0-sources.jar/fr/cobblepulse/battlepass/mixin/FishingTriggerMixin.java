package fr.cobblepulse.battlepass.mixin;

import fr.cobblepulse.battlepass.quest.QuestHooks;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import net.minecraft.class_1536;
import net.minecraft.class_1799;
import net.minecraft.class_2058;
import net.minecraft.class_3222;

/** Peche a la canne vanilla (objets pris) pour les quetes de peche. */
@Mixin(class_2058.class)
public abstract class FishingTriggerMixin {
    @Inject(method = "trigger", at = @At("HEAD"))
    private void cpbp$fished(class_3222 player, class_1799 rod, class_1536 hook, Collection<class_1799> items, CallbackInfo ci) {
        QuestHooks.onFished(player, items);
    }
}
