package fr.cobblepulse.battlepass.mixin;

import fr.cobblepulse.battlepass.quest.QuestHooks;
import net.minecraft.class_3222;
import net.minecraft.class_3445;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Statistiques vanilla (fabrication, distance, elevage, statistique libre) pour les quetes. */
@Mixin(class_3222.class)
public abstract class ServerPlayerMixin {
    @Inject(method = "awardStat(Lnet/minecraft/stats/Stat;I)V", at = @At("HEAD"))
    private void cpbp$awardStat(class_3445<?> stat, int amount, CallbackInfo ci) {
        QuestHooks.onStat((class_3222) (Object) this, stat, amount);
    }
}
