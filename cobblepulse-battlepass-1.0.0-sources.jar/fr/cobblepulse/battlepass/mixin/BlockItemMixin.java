package fr.cobblepulse.battlepass.mixin;

import fr.cobblepulse.battlepass.quest.PlacedBlocks;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Memorise les blocs poses par les joueurs (ils ne comptent pas pour les quetes de minage). */
@Mixin(class_1747.class)
public abstract class BlockItemMixin {
    @Inject(method = "place(Lnet/minecraft/world/item/context/BlockPlaceContext;)Lnet/minecraft/world/InteractionResult;", at = @At("RETURN"))
    private void cpbp$place(class_1750 ctx, CallbackInfoReturnable<class_1269> cir) {
        if (ctx.method_8036() != null && ctx.method_8045() instanceof class_3218 level && cir.getReturnValue().method_23665()) {
            PlacedBlocks.mark(level, ctx.method_8037());
        }
    }
}
