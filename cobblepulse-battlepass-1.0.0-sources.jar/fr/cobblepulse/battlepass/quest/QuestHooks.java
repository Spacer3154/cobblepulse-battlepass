package fr.cobblepulse.battlepass.quest;

import com.cobblemon.mod.common.api.Priority;
import com.cobblemon.mod.common.api.battles.model.PokemonBattle;
import com.cobblemon.mod.common.api.battles.model.actor.ActorType;
import com.cobblemon.mod.common.api.battles.model.actor.BattleActor;
import com.cobblemon.mod.common.api.events.CobblemonEvents;
import com.cobblemon.mod.common.api.pokedex.PokedexEntryProgress;
import com.cobblemon.mod.common.battles.actor.PlayerBattleActor;
import com.cobblemon.mod.common.battles.pokemon.BattlePokemon;
import com.cobblemon.mod.common.pokemon.Pokemon;
import com.cobblemon.mod.common.trade.PlayerTradeParticipant;
import com.cobblemon.mod.common.trade.TradeParticipant;
import fr.cobblepulse.battlepass.BattlePass;
import fr.cobblepulse.battlepass.core.Players;
import fr.cobblepulse.battlepass.hunt.Hunts;
import kotlin.Unit;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2758;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3445;
import net.minecraft.class_3448;
import net.minecraft.class_3468;
import net.minecraft.class_7923;
import java.util.Collection;
import java.util.Set;
import java.util.UUID;

/** Branchements des evenements Cobblemon, Fabric et vanilla (via mixins) sur le moteur de quetes. */
public final class QuestHooks {
    private QuestHooks() {}

    private static void safe(String what, Runnable r) {
        try {
            r.run();
        } catch (Throwable t) {
            BattlePass.LOG.warn("[BattlePass] Evenement {} : {}", what, t.toString());
        }
    }

    public static void register() {
        CobblemonEvents.POKEMON_CAPTURED.subscribe(Priority.NORMAL, e -> {
            safe("capture", () -> {
                class_3222 p = e.getPlayer();
                Pokemon pk = e.getPokemon();
                String ball = null;
                try {
                    ball = e.getPokeBallEntity().getPokeBall().getName().toString();
                } catch (Throwable ignored) {
                }
                Ctx c = new Ctx().pokemon(pk).ball(ball).at(p.method_51469(), p.method_24515());
                Quests.fire(p, "capture", c, 1);
                Hunts.onCapture(p, pk);
            });
            return Unit.INSTANCE;
        });
        CobblemonEvents.BATTLE_FAINTED.subscribe(Priority.NORMAL, e -> {
            safe("ko", () -> {
                BattlePokemon killed = e.getKilled();
                if (killed == null || killed.actor == null || killed.actor.getType() != ActorType.WILD) return;
                PokemonBattle b = e.getBattle();
                Pokemon pk = killed.getOriginalPokemon();
                for (BattleActor a : b.getActors()) {
                    if (!(a instanceof PlayerBattleActor)) continue;
                    for (UUID id : a.getPlayerUUIDs()) {
                        class_3222 p = Players.get(id);
                        if (p != null) Quests.fire(p, "vaincre_sauvage", new Ctx().pokemon(pk).at(p.method_51469(), p.method_24515()), 1);
                    }
                }
            });
            return Unit.INSTANCE;
        });
        CobblemonEvents.BATTLE_VICTORY.subscribe(Priority.NORMAL, e -> {
            safe("victoire", () -> {
                if (e.getWasWildCapture()) return;
                PokemonBattle b = e.getBattle();
                String kind = b.isPvP() ? "joueur" : b.isPvN() ? "dresseur" : b.isPvW() ? "sauvage" : "";
                for (BattleActor a : e.getWinners()) {
                    if (!(a instanceof PlayerBattleActor)) continue;
                    for (UUID id : a.getPlayerUUIDs()) {
                        class_3222 p = Players.get(id);
                        if (p != null) Quests.fire(p, "victoire_combat", new Ctx().combat(kind), 1);
                    }
                }
            });
            return Unit.INSTANCE;
        });
        CobblemonEvents.EVOLUTION_COMPLETE.subscribe(Priority.NORMAL, e -> {
            safe("evolution", () -> {
                Pokemon pk = e.getPokemon();
                class_3222 p = pk.getOwnerPlayer();
                if (p != null) Quests.fire(p, "evolution", new Ctx().pokemon(pk), 1);
            });
            return Unit.INSTANCE;
        });
        CobblemonEvents.HATCH_EGG_POST.subscribe(Priority.NORMAL, e -> {
            safe("eclosion", () -> Quests.fire(e.getPlayer(), "eclosion", new Ctx().pokemon(e.getPokemon()), 1));
            return Unit.INSTANCE;
        });
        CobblemonEvents.TRADE_EVENT_POST.subscribe(Priority.NORMAL, e -> {
            safe("echange", () -> {
                trade(e.getTradeParticipant1(), e.getTradeParticipant2Pokemon());
                trade(e.getTradeParticipant2(), e.getTradeParticipant1Pokemon());
            });
            return Unit.INSTANCE;
        });
        CobblemonEvents.LEVEL_UP_EVENT.subscribe(Priority.NORMAL, e -> {
            safe("niveau", () -> {
                Pokemon pk = e.getPokemon();
                class_3222 p = pk.getOwnerPlayer();
                int gained = e.getNewLevel() - e.getOldLevel();
                if (p != null && gained > 0) Quests.fire(p, "niveau", new Ctx().pokemon(pk), gained);
            });
            return Unit.INSTANCE;
        });
        CobblemonEvents.BOBBER_SPAWN_POKEMON_POST.subscribe(Priority.NORMAL, e -> {
            safe("peche_pokemon", () -> {
                class_1657 owner = e.getBobber().method_6947();
                if (owner instanceof class_3222 p) {
                    Pokemon pk = e.getPokemon() == null ? null : e.getPokemon().getPokemon();
                    Quests.fire(p, "peche_pokemon", new Ctx().pokemon(pk).at(p.method_51469(), p.method_24515()), 1);
                }
            });
            return Unit.INSTANCE;
        });
        CobblemonEvents.FOSSIL_REVIVED.subscribe(Priority.NORMAL, e -> {
            safe("fossile", () -> {
                if (e.getPlayer() != null) Quests.fire(e.getPlayer(), "fossile", new Ctx().pokemon(e.getPokemon()), 1);
            });
            return Unit.INSTANCE;
        });
        CobblemonEvents.BERRY_HARVEST.subscribe(Priority.NORMAL, e -> {
            safe("baies", () -> {
                class_3222 p = e.getPlayer();
                class_1792 berry = e.getBerry().item();
                Quests.fire(p, "baies", new Ctx().item(new class_1799(berry)), 1);
            });
            return Unit.INSTANCE;
        });
        CobblemonEvents.APRICORN_HARVESTED.subscribe(Priority.NORMAL, e -> {
            safe("noigrumes", () -> Quests.fire(e.getPlayer(), "noigrumes", new Ctx().item(new class_1799(e.getApricorn().item())), 1));
            return Unit.INSTANCE;
        });
        CobblemonEvents.POKEDEX_DATA_CHANGED_PRE.subscribe(Priority.LOWEST, e -> {
            safe("pokedex", () -> {
                if (e.isCanceled() || e.getKnowledge() != PokedexEntryProgress.OWNED) return;
                Pokemon pk = (Pokemon) call(e.getDataSource(), "getPokemon");
                class_2960 species = pk != null ? pk.getSpecies().getResourceIdentifier()
                        : (class_2960) call(call(e.getRecord(), "getSpeciesDexRecord"), "getId");
                if (species == null) return;
                if (e.getPokedexManager().getKnowledgeForSpecies(species) == PokedexEntryProgress.OWNED) return;
                class_3222 p = Players.get(e.getPlayerUUID());
                if (p != null) Quests.fire(p, "pokedex", new Ctx().pokemon(pk), 1);
            });
            return Unit.INSTANCE;
        });

        PlayerBlockBreakEvents.AFTER.register((level, player, pos, state, be) -> {
            if (!(player instanceof class_3222 p) || !(level instanceof class_3218 sl)) return;
            safe("bloc", () -> onBlockBroken(p, sl, pos, state));
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.method_5529() instanceof class_3222 p && !(entity instanceof class_1657)) {
                safe("tuer", () -> Quests.fire(p, "tuer", new Ctx().entity(entity.method_5864()).at(p.method_51469(), entity.method_24515()), 1));
            }
        });
    }

    /** Appel sans argument par reflexion (API dont la forme varie selon les versions de Cobblemon). */
    private static Object call(Object o, String method) {
        if (o == null) return null;
        try {
            return o.getClass().getMethod(method).invoke(o);
        } catch (Throwable t) {
            return null;
        }
    }

    private static void trade(TradeParticipant who, Pokemon received) {
        if (who instanceof PlayerTradeParticipant pp) Quests.fire(pp.getPlayer(), "echange", new Ctx().pokemon(received), 1);
    }

    // ------------------------------------------------------------------ Blocs (minage, recolte)

    private static class_2758 age(class_2680 st) {
        for (class_2769<?> prop : st.method_28501()) {
            if (prop instanceof class_2758 ip && prop.method_11899().equals("age")) return ip;
        }
        return null;
    }

    /** Culture mure (propriete "age" au maximum) ou bloc recolte (melon, citrouille, canne a sucre...). */
    static boolean isHarvest(class_2680 st) {
        class_2758 ip = age(st);
        if (ip != null) {
            int max = 0;
            for (Integer v : ip.method_11898()) max = Math.max(max, v);
            return st.method_11654(ip) >= max;
        }
        class_2248 b = st.method_26204();
        return b == class_2246.field_46283 || b == class_2246.field_46282 || b == class_2246.field_10424 || b == class_2246.field_10029 || b == class_2246.field_10211
                || b == class_2246.field_10463 || b == class_2246.field_10251 || b == class_2246.field_10559;
    }

    private static void onBlockBroken(class_3222 p, class_3218 level, class_2338 pos, class_2680 state) {
        boolean placed = PlacedBlocks.consume(level, pos);
        boolean grows = age(state) != null;
        Ctx c = new Ctx().block(state).at(level, pos);
        if (isHarvest(state) && (grows || !placed)) Quests.fire(p, "recolte", c, 1);
        if (!placed && !grows) Quests.fire(p, "minage", c, 1);
    }

    // ------------------------------------------------------------------ Statistiques (mixin ServerPlayer.awardStat)

    private static final Set<class_2960> DISTANCE = Set.of(class_3468.field_15377, class_3468.field_15364, class_3468.field_15423,
            class_3468.field_15394, class_3468.field_15401, class_3468.field_15376, class_3468.field_15396, class_3468.field_15374);

    private static <T> String statId(class_3445<T> stat) {
        class_3448<T> type = stat.method_14949();
        class_2960 t = class_7923.field_41193.method_10221(type);
        class_2960 v = type.method_14959().method_10221(stat.method_14951());
        return t + "/" + v;
    }

    public static void onStat(class_3222 p, class_3445<?> stat, int amount) {
        if (amount <= 0) return;
        try {
            if (stat.method_14949() == class_3468.field_15419 && stat.method_14951() instanceof class_2960 rl) {
                if (DISTANCE.contains(rl)) {
                    if (Quests.used("distance")) Quests.fire(p, "distance", new Ctx(), amount);
                    return;
                }
                if (rl.equals(class_3468.field_15410) && Quests.used("elevage")) Quests.fire(p, "elevage", new Ctx(), amount);
                if (rl.equals(class_3468.field_15417) || rl.equals(class_3468.field_33558) || rl.equals(class_3468.field_15429)
                        || rl.equals(class_3468.field_15400) || rl.equals(class_3468.field_15422)) return;
            } else if (stat.method_14949() == class_3468.field_15370 && stat.method_14951() instanceof class_1792 item) {
                if (Quests.used("fabrication")) Quests.fire(p, "fabrication", new Ctx().item(new class_1799(item)), amount);
            }
            if (Quests.used("stat")) Quests.fire(p, "stat", new Ctx().stat(statId(stat)), amount);
        } catch (Throwable t) {
            BattlePass.LOG.debug("[BattlePass] stat : {}", t.toString());
        }
    }

    // ------------------------------------------------------------------ Autres mixins

    public static void onFished(class_3222 p, Collection<class_1799> items) {
        if (!Quests.used("peche")) return;
        for (class_1799 s : items) if (!s.method_7960()) Quests.fire(p, "peche", new Ctx().item(s.method_7972()), s.method_7947());
    }

    public static void onConsumed(class_3222 p, class_1799 s) {
        if (s == null || s.method_7960() || !Quests.used("manger")) return;
        if (s.method_57824(net.minecraft.class_9334.field_50075) == null) return;
        Quests.fire(p, "manger", new Ctx().item(s.method_7972()), 1);
    }

    // ------------------------------------------------------------------ Tour de Combat (mixins sur Battletower)

    public static void towerFloor(UUID player, String name, int floor) {
        safe("tour_etage", () -> Quests.fire(player, name, "tour_etage", new Ctx().floor(floor), 1));
    }

    public static void towerComplete(UUID player, String name) {
        safe("tour_complete", () -> Quests.fire(player, name, "tour_complete", new Ctx(), 1));
    }

    public static void towerBoss(UUID player, String name) {
        safe("tour_boss", () -> Quests.fire(player, name, "tour_boss", new Ctx(), 1));
    }
}
