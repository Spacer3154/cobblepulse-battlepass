package fr.cobblepulse.battlepass.quest;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_3218;

/**
 * Memorise les blocs poses par les joueurs (anti-triche des quetes de minage : poser puis casser ne compte pas).
 * En memoire seulement, limite aux 200 000 derniers blocs par dimension.
 */
public final class PlacedBlocks {
    private static final int MAX = 200_000;
    private static final Map<String, LinkedHashMap<Long, Boolean>> BY_LEVEL = new HashMap<>();

    private PlacedBlocks() {}

    private static LinkedHashMap<Long, Boolean> map(class_3218 level) {
        return BY_LEVEL.computeIfAbsent(level.method_27983().method_29177().toString(), k -> new LinkedHashMap<Long, Boolean>(1024, 0.75f, false) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<Long, Boolean> eldest) {
                return size() > MAX;
            }
        });
    }

    public static void mark(class_3218 level, class_2338 pos) {
        map(level).put(pos.method_10063(), Boolean.TRUE);
    }

    /** @return true si le bloc avait ete pose par un joueur (et l'oublie). */
    public static boolean consume(class_3218 level, class_2338 pos) {
        return map(level).remove(pos.method_10063()) != null;
    }

    public static void clear() {
        BY_LEVEL.clear();
    }
}
