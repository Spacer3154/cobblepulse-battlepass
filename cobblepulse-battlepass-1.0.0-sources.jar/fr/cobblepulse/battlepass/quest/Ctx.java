package fr.cobblepulse.battlepass.quest;

import com.cobblemon.mod.common.pokemon.Pokemon;
import net.minecraft.class_1299;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/** Contexte d'un evenement de quete (seuls les champs utiles sont renseignes). */
public final class Ctx {
    public Pokemon pokemon;
    /** Identifiant de la Poke Ball (capture). */
    public String ball;
    public class_3218 level;
    public class_2338 pos;
    /** sauvage, dresseur ou joueur. */
    public String combat;
    public class_2680 block;
    public class_1799 item;
    public class_1299<?> entity;
    /** Statistique "type/valeur" (ex. minecraft:custom/minecraft:jump). */
    public String stat;
    /** Chasse : facile, normal, moyen, difficile ou globale. */
    public String difficulte;
    /** Etage de la Tour de Combat. */
    public int floor;

    public Ctx pokemon(Pokemon p) {
        this.pokemon = p;
        return this;
    }

    public Ctx ball(String b) {
        this.ball = b;
        return this;
    }

    public Ctx at(class_3218 level, class_2338 pos) {
        this.level = level;
        this.pos = pos;
        return this;
    }

    public Ctx combat(String c) {
        this.combat = c;
        return this;
    }

    public Ctx block(class_2680 s) {
        this.block = s;
        return this;
    }

    public Ctx item(class_1799 s) {
        this.item = s;
        return this;
    }

    public Ctx entity(class_1299<?> t) {
        this.entity = t;
        return this;
    }

    public Ctx stat(String s) {
        this.stat = s;
        return this;
    }

    public Ctx difficulte(String d) {
        this.difficulte = d;
        return this;
    }

    public Ctx floor(int f) {
        this.floor = f;
        return this;
    }
}
