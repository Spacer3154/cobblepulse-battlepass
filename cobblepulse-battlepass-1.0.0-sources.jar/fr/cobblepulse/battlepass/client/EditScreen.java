package fr.cobblepulse.battlepass.client;

import com.google.gson.JsonObject;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Base des sous-editeurs (recompense, quete, Pokemon de chasse) : formulaire defilant + Valider / Annuler. */
public abstract class EditScreen extends class_437 {
    protected final class_437 parent;
    protected final JsonObject obj;
    private final Consumer<JsonObject> onSave;
    protected Form form;
    protected int px;
    protected int py;
    protected int pw;
    protected int ph;
    protected double keepScroll;
    protected String message = "";
    protected int messageColor = Ui.MUTED;

    protected EditScreen(String title, class_437 parent, JsonObject obj, Consumer<JsonObject> onSave) {
        super(class_2561.method_43470(title));
        this.parent = parent;
        this.obj = obj;
        this.onSave = onSave;
    }

    /** Ajoute les champs du formulaire. */
    protected abstract void fields(Form f);

    /** Zone de droite reservee (apercu) en pixels. */
    protected int previewWidth() {
        return 0;
    }

    private int savedGuiScale = -1;

    /** Reduit l'echelle d'interface si l'ecran est trop petit (restauree a la fermeture). */
    private void fitGuiScale() {
        net.minecraft.class_1041 win = field_22787.method_22683();
        int cur = (int) win.method_4495();
        int s = cur;
        while (s > 1 && (win.method_4489() / s < 480 || win.method_4506() / s < 280)) s--;
        if (s != cur) {
            if (savedGuiScale < 0) savedGuiScale = cur;
            win.method_15997(s);
            this.field_22789 = win.method_4486();
            this.field_22790 = win.method_4502();
        }
    }

    @Override
    public void method_25432() {
        super.method_25432();
        if (savedGuiScale > 0) {
            field_22787.method_22683().method_15997(savedGuiScale);
            savedGuiScale = -1;
        }
    }

    @Override
    protected void method_25426() {
        fitGuiScale();
        pw = Math.min(field_22789 - 16, 620);
        ph = field_22790 - 16;
        px = (field_22789 - pw) / 2;
        py = 8;
        rebuild();
    }

    protected void rebuild() {
        if (form != null) keepScroll = form.scroll();
        method_37067();
        form = new Form(this::method_37063, px + 6, py + 22, pw - 12 - previewWidth(), ph - 50);
        fields(form);
        form.setScroll(keepScroll);
        form.layout();
        method_37063(class_4185.method_46430(class_2561.method_43470("Valider"), b -> {
            onSave.accept(obj);
            field_22787.method_1507(parent);
        }).method_46434(px + pw - 196, py + ph - 24, 92, 18).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Annuler"), b -> field_22787.method_1507(parent)).method_46434(px + pw - 100, py + ph - 24, 92, 18).method_46431());
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25420(class_332 g, int mouseX, int mouseY, float partialTick) {
        super.method_25420(g, mouseX, mouseY, partialTick);
        Ui.panel(g, px, py, pw, ph, Ui.PANEL, Ui.BORDER);
        g.method_25294(px + 1, py + 18, px + pw - 1, py + 19, Ui.BORDER);
    }

    @Override
    public void method_25394(class_332 g, int mouseX, int mouseY, float partialTick) {
        super.method_25394(g, mouseX, mouseY, partialTick);
        Ui.text(g, field_22785.getString(), px + 8, py + 6, Ui.GOLD);
        if (!message.isEmpty()) Ui.text(g, Ui.cut(message, pw - 220), px + 8, py + ph - 19, messageColor);
        extra(g, mouseX, mouseY);
        form.render(g, mouseX, mouseY);
    }

    /** Dessin additionnel (apercu). */
    protected void extra(class_332 g, int mouseX, int mouseY) {}

    @Override
    public boolean method_25402(double mx, double my, int button) {
        if (form.mouseClicked(mx, my)) return true;
        return super.method_25402(mx, my, button);
    }

    @Override
    public boolean method_25401(double mx, double my, double sx, double sy) {
        if (form.mouseScrolled(mx, my, sy)) return true;
        return super.method_25401(mx, my, sx, sy);
    }
}
