package fr.cobblepulse.battlepass.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import fr.cobblepulse.battlepass.BattlePass;
import fr.cobblepulse.battlepass.net.Payloads;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Cote client : ecran du passe, editeur graphique et touche d'ouverture. */
public final class BattlePassClient implements ClientModInitializer {
    private static class_304 openKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new class_304("key.cobblepulse_battlepass.open", class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_B, "key.categories.cobblepulse_battlepass"));
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.method_1436()) {
                if (mc.field_1724 != null && mc.field_1755 == null) Ui.send("open");
            }
        });
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Data.TYPE, (payload, ctx) -> ctx.client().execute(() -> receive(payload.kind(), payload.json())));
        if ("true".equals(System.getProperty("cobblepulse_battlepass.clienttest"))) ClientSelfTest.install();
        BattlePass.LOG.info("[BattlePass] Client initialise");
    }

    static void receive(String kind, String json) {
        class_310 mc = class_310.method_1551();
        JsonObject o;
        try {
            o = JsonParser.parseString(json).getAsJsonObject();
        } catch (Exception e) {
            BattlePass.LOG.warn("[BattlePass] Donnees illisibles ({}) : {}", kind, e.toString());
            return;
        }
        switch (kind) {
            case "pass_open" -> {
                Ui.clearCaches();
                mc.method_1507(new PassScreen(o));
            }
            case "pass", "pass_full" -> {
                if (mc.field_1755 instanceof PassScreen s) s.update(o, kind.equals("pass_full"));
            }
            case "candidates" -> {
                if (mc.field_1755 instanceof PassScreen s) s.showCandidates(o);
            }
            case "toast" -> {
                boolean ok = o.has("ok") && o.get("ok").getAsBoolean();
                String msg = o.has("message") ? o.get("message").getAsString() : "";
                if (mc.field_1755 instanceof PassScreen s) s.toast(ok, msg);
                else if (mc.field_1755 instanceof AdminScreen s) s.toast(ok, msg);
                else if (mc.field_1724 != null) mc.field_1724.method_7353(class_2561.method_43470(msg), true);
            }
            case "admin_open" -> mc.method_1507(new AdminScreen(o));
            case "admin_data" -> {
                if (mc.field_1755 instanceof AdminScreen s) s.refreshData(o);
                else if (mc.field_1755 instanceof EditScreen e && e.parent instanceof AdminScreen s) s.refreshData(o);
            }
            case "admin_result" -> {
                if (mc.field_1755 instanceof AdminScreen s) s.onResult(o);
            }
            case "admin_player" -> {
                if (mc.field_1755 instanceof AdminScreen s) s.onPlayer(o);
            }
            case "pokemon_check" -> {
                if (mc.field_1755 instanceof RewardEditScreen s) s.onCheck(o);
            }
            default -> {
            }
        }
    }
}
