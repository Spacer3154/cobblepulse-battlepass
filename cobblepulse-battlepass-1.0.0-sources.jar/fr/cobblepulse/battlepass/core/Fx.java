package fr.cobblepulse.battlepass.core;

import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5903;
import net.minecraft.class_5904;
import net.minecraft.class_5905;
import net.minecraft.class_7923;

/** Titres et sons. */
public final class Fx {
    private Fx() {}

    public static void title(class_3222 p, String title, String subtitle) {
        if (p == null || p.field_13987 == null) return;
        try {
            p.field_13987.method_14364(new class_5905(4, 30, 8));
            p.field_13987.method_14364(new class_5903(TextUtil.legacy(subtitle == null ? "" : subtitle)));
            p.field_13987.method_14364(new class_5904(TextUtil.legacy(title == null ? "" : title)));
        } catch (Throwable ignored) {
        }
    }

    public static void sound(class_3222 p, class_3414 sound, float volume, float pitch) {
        if (p == null || sound == null || p.field_13987 == null) return;
        p.method_17356(sound, class_3419.field_15250, volume, pitch);
    }

    public static void sound(class_3222 p, String id, float volume, float pitch) {
        sound(p, soundById(id, class_3417.field_14709), volume, pitch);
    }

    public static class_3414 soundById(String id, class_3414 fallback) {
        class_2960 rl = id == null ? null : class_2960.method_12829(id.trim());
        if (rl == null || !class_7923.field_41172.method_10250(rl)) return fallback;
        return class_7923.field_41172.method_10223(rl);
    }

    public static void click(class_3222 p) {
        sound(p, class_3417.field_15015.comp_349(), 0.6f, 1.2f);
    }
}
